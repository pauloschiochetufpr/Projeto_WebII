package com.manutencao.trabalhoweb2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrabalhoWeb2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
